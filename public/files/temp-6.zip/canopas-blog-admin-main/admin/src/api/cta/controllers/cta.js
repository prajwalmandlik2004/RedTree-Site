"use strict";

/**
 * cta controller
 */

const { createCoreController } = require("@strapi/strapi").factories;

module.exports = createCoreController("api::cta.cta");
