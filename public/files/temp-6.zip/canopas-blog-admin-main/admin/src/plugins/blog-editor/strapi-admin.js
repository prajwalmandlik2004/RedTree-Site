module.exports = require("./admin/src").default;
