"use strict";

const register = require("./register");

module.exports = {
  register,
};
