/**
 *
 * PluginIcon
 *
 */

import React from "react";
import { List } from "@strapi/icons";

const PluginIcon = () => <List />;

export default PluginIcon;
