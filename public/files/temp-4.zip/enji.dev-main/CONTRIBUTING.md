## Setup the Project

The following steps will get you up and running to contribute to this repository:

1. Fork the repo (click the Fork button at the top right of this page)
2. Clone your fork locally

   ```bash
   git clone https://github.com/<your_github_username>/enji.dev.git
   cd enji.dev
   ```

3. Setup all the dependencies and packages by running `pnpm install`
