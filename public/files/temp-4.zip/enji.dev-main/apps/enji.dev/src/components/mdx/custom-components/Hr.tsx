import clsx from 'clsx';

export function Hr() {
  return <hr className={clsx('mdx-hr')} />;
}
