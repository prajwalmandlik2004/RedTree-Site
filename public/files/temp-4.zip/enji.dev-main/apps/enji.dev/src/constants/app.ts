// for each reaction (CLAPPING, THINGKING, AMAZED)
export const MAX_REACTIONS_PER_SESSION = 15;

// max shares that will be counted
export const MAX_SHARES_PER_SESSION = 10;

// max views that will be counted
export const MAX_VIEWS_PER_SESSION = 20;
